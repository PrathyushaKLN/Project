package co.vinod.mait.dao;

import java.util.List;

import co.vinod.mait.entity.Employee;

public interface EmployeeDao {
	
	// CRUD operations
	
		public void addEmployee(Employee emp) throws DaoException;
		public Employee getEmployee(int empno) throws DaoException;
		public void updateEmployee(int empno,int salary) throws DaoException;
		public void deleteEmployee(int empno) throws DaoException;
		
		// Queries
		
		public List<Employee> getAllEmployees() throws DaoException;
		public Employee getEmployeeByName(String Name) throws DaoException;

}
