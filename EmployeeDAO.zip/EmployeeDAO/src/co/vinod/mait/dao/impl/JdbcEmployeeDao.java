package co.vinod.mait.dao.impl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.EmployeeDao;
import co.vinod.mait.entity.Employee;
import co.vinod.mait.util.DbUtil;


public class JdbcEmployeeDao implements EmployeeDao{

	@Override
	public void addEmployee(Employee emp) throws DaoException {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			String sql = "insert into employee values(?,?,?,?)";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, emp.getEmpno());
			stmt.setString(2, emp.getName());
			stmt.setInt(3, emp.getSalary());
			stmt.setString(4, emp.getAddress());
			stmt.executeUpdate();
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, null);
		}
		
	}

	@Override
	public  Employee getEmployee(int empno) throws DaoException {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			String sql = "select * from employee where empno=?";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, empno);
			rs = stmt.executeQuery();
			if(rs.next()){
				Employee emp = getEmployeeFromResultSet(rs);
				return emp;
			}
			
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, rs);
		}
		return null;
	}

	@Override
	public void updateEmployee(int empno, int salary) throws DaoException {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			String sql = "update employee set salary=? where empno=?";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, salary);
			stmt.setInt(2, empno);
			if(stmt.executeUpdate()==0){
				throw new DaoException("No data found!");
			}
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, null);
		}	
	}

	@Override
	public void deleteEmployee(int empno) throws DaoException {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			String sql = "delete from employee where empno= ?";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, empno);
			if(stmt.executeUpdate()==0){
				throw new DaoException("No data found!");
			}
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, null);
		}
		
	}

	@Override
	public List<Employee> getAllEmployees() throws DaoException {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		List<Employee> list = new ArrayList<>();
		
		try {
			String sql = "select * from employee";
			conn = DbUtil.getConnection();			
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();

			while(rs.next()){
				Employee emp = getEmployeeFromResultSet(rs);
				list.add(emp);
			}
			
		} catch (Exception e) {
			throw new DaoException(e);
		} finally {
			DbUtil.releaseResource(conn, stmt, rs);
		}
		return list;
	}

	@Override
	public Employee getEmployeeByName(String Name) throws DaoException {
		// TODO Auto-generated method stub
		return null;
	}
	
	private Employee getEmployeeFromResultSet(ResultSet rs) throws SQLException {
		Employee emp = new Employee();
		emp.setEmpno(rs.getInt("empno"));
		emp.setName(rs.getString("Name"));
		emp.setSalary(rs.getInt("salary"));
		emp.setAddress(rs.getString("address"));
		return emp;
	}

	
}
