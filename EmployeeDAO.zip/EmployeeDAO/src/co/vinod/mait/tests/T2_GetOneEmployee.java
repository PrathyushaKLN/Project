package co.vinod.mait.tests;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.impl.JdbcEmployeeDao;
import co.vinod.mait.entity.Employee;

public class T2_GetOneEmployee {

	public static void main(String[] args) throws DaoException {
		
		JdbcEmployeeDao dao = new JdbcEmployeeDao();
		
		int empno = 101;
		Employee p = dao.getEmployee(empno);
		if(p==null){
			System.out.println("No data found");
		}
		else {
			System.out.println(p);
		}
		
	}
}
