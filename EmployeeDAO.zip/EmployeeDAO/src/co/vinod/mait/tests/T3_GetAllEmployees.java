package co.vinod.mait.tests;

import java.util.List;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.impl.JdbcEmployeeDao;
import co.vinod.mait.entity.Employee;

public class T3_GetAllEmployees {

	public static void main(String[] args) throws DaoException {
		JdbcEmployeeDao dao = new JdbcEmployeeDao();

		List<Employee> list = dao.getAllEmployees();
		for (Employee p : list) {
			System.out.println(p.getName());
		}
	}

}
