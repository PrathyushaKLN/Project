package co.vinod.mait.tests;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.impl.JdbcEmployeeDao;
import co.vinod.mait.entity.Employee;

public class T1_AddEmployee {

	public static void main(String[] args) throws DaoException {

		Employee emp = new Employee(101, "Prathyu", 5000, "ap");
		JdbcEmployeeDao dao = new JdbcEmployeeDao();
		dao.addEmployee(emp);
		System.out.println("Employee data added to db.");
		
	}
}
