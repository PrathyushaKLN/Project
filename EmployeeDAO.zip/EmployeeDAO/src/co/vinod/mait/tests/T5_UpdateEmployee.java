package co.vinod.mait.tests;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.impl.JdbcEmployeeDao;

public class T5_UpdateEmployee {

	public static void main(String[] args) throws DaoException {
		
		JdbcEmployeeDao dao = new JdbcEmployeeDao();
		int empno=101;
		int salary=6000;
		dao.updateEmployee(empno,salary);
		System.out.println("Employee Data Updated");
	}

}
