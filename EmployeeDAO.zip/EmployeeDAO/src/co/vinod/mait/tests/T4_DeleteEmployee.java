package co.vinod.mait.tests;

import co.vinod.mait.dao.DaoException;
import co.vinod.mait.dao.impl.JdbcEmployeeDao;

public class T4_DeleteEmployee {

	public static void main(String[] args) throws DaoException {
		
		JdbcEmployeeDao dao = new JdbcEmployeeDao();
		int empno=101;
		
		dao.deleteEmployee(empno);
		System.out.println("Succeeded!");
	}

}
