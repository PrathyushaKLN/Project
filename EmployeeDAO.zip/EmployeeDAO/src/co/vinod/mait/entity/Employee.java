//create table person(id number,firstname varchar2(30),lastname varchar2(30),
//phone varchar2(30),email varchar2(50))
package co.vinod.mait.entity;

public class Employee {

	private int empno;
	private String Name;
	private int salary;
	private String address;

	public Employee() {
	}

	

	public Employee(int empno, String name, int salary, String address) {
		super();
		this.empno = empno;
		Name = name;
		this.salary = salary;
		this.address = address;
	}



	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}


	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", Name=" + Name + ", salary=" + salary + ", address=" + address + "]";
	}

	

}
