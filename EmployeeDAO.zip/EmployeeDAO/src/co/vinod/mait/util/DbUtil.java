package co.vinod.mait.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import co.vinod.mait.dao.DaoException;

public class DbUtil {

	private DbUtil() {
	}

	public static Connection getConnection() throws DaoException {
		try {
			String driver, url, user, password;
			driver = "oracle.jdbc.driver.OracleDriver";
			url = "jdbc:oracle:thin:@localhost:1521:xe";
			user = "system";
			password = "1234";

			Class.forName(driver);
			return DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

	public static void releaseResource(Connection conn, Statement stmt, ResultSet rs)
			throws DaoException {
		try {
			if(rs!=null){
				rs.close();
			}
			if(stmt!=null){
				stmt.close();
			}
			if(conn!=null){
				conn.close();
			}
		} catch (Exception e) {
			throw new DaoException(e);
		}
	}

}
