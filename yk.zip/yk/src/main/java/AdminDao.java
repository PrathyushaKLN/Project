import java.util.*;
import java.sql.*;
public class AdminDao {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(Adm e){
		int status=0;
		try{
			Connection con=AdminDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into signup values (?,?,?,?,?)");
			ps.setString(1,e.getFirstName());
			ps.setString(2,e.getLastName());
			ps.setString(3,e.getEmail());
			ps.setString(4,e.getPassword());
			ps.setString(5,e.getConfirmPassword());
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int update(Adm e){
		int status=0;
		try{
			Connection con=AdminDao.getConnection();
			PreparedStatement ps=con.prepareStatement("update signup set firstname=?, lastname=?, password=?, confirmpassword=? where email=?");
			ps.setString(1,e.getFirstName());
			ps.setString(2,e.getLastName());
			ps.setString(3,e.getPassword());
			ps.setString(4,e.getConfirmPassword());
			ps.setString(5,e.getEmail());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int delete(String password){
		int status=0;
		try{
			Connection con=AdminDao.getConnection();
			PreparedStatement ps1=con.prepareStatement("delete from signup where password=?");
			ps1.setString(1,password);
			System.out.println(password);
			status=ps1.executeUpdate();
			System.out.println(status);
			
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return status;
	}
}
