import java.util.*;
import java.sql.*;
@WebServlet("/AdminDao")
public class AdminDao extends HttpServlet {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		}catch(Exception e){System.out.println(e);}
		return con;
		public static int edit(Emp e){
			int status=0;
			try{
				Connection con=EmpDao.getConnection();
				PreparedStatement ps=con.prepareStatement("insert into user905(id,name,password,email,country,age,department,salary) values (crud.nextval,?,?,?,?,?,?,?)");
				ps.setString(1,e.getName());
				ps.setString(2,e.getPassword());
				ps.setString(3,e.getEmail());
				ps.setString(4,e.getCountry());
				ps.setInt(5,e.getAge());
				ps.setString(6,e.getDepartment());
				ps.setInt(7,e.getSalary());
				status=ps.executeUpdate();
				
				con.close();
			}catch(Exception ex){ex.printStackTrace();}
			
			return status;
		}
	}
}
