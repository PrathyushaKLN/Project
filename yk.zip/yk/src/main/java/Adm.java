public class Adm {

private String firstname,lastname,email,password,confirmpassword;

public String getFirstName() {
	return firstname;
}
public void setFirstName(String firstname) {
	this.firstname = firstname;
}
public String getLastName() {
	return lastname;
}
public void setLastName(String lastname) {
	this.lastname =lastname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getConfirmPassword() {
	return confirmpassword;
}
public void setConfirmPassword(String confirmpassword) {
	this.confirmpassword = confirmpassword;
}
}
