
import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		AdminDao.delete(id);
		response.sendRedirect("ViewServlet");
	}}	
	
	