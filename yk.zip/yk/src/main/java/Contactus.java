import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Contactus")
public class Contactus extends HttpServlet {
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a=req.getParameter("firstname");
		String b=req.getParameter("email");
		String c=req.getParameter("message");
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		PreparedStatement ps=con.prepareStatement("insert into contactus values(?,?,?)");
		ps.setString(1,a);
		ps.setString(2,b);
		ps.setString(3,c);
		ps.execute();
		res.sendRedirect("contact.html");
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
}
}