package com.javatpoint.controllers;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.javatpoint.beans.Emp;

@Controller
public class EmpController {
Emp emp=new Emp();
	@RequestMapping("/empform1")
	public ModelAndView showform(){
		return new ModelAndView("empform","command",new Emp());
	}
	@RequestMapping("/loginform")
	public ModelAndView loginform(){
		return new ModelAndView("loginform","command",new Emp());
	}

	@RequestMapping(value="/signup",method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("emp") Emp emp)
	{
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
		PreparedStatement st=con.prepareStatement("insert into  reg values(?,?,?,?,?)");
			System.out.println(emp.getId()+" "+emp.getName()+" "+emp.getAddress()+" "+emp.getPhoneno()+" "+emp.getPassword());
			st.setString(1,emp.getId());
			st.setString(2,emp.getName());
			st.setString(3,emp.getAddress());
			st.setString(4,emp.getPhoneno());
			st.setString(5,emp.getPassword());
			st.execute();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return new ModelAndView("redirect:/loginform");
	}
	
	@RequestMapping(value="/login",method = RequestMethod.POST)
	public ModelAndView loginform(@ModelAttribute("emp") Emp emp){
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
		PreparedStatement st=con.prepareStatement("select * from reg where name=? and password=?");
			
			st.setString(1,emp.getName());
			st.setString(2,emp.getPassword());	
			ResultSet rs=st.executeQuery();
			int x=0;
			while(rs.next())
			{
				x=1;//when there is data
			}
			if(x==1)
			{
				
				String message = "Success";  
		        return new ModelAndView(message); 
			}
			else
			{
				return new ModelAndView("redirect:/loginform");
			}
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return new ModelAndView("redirect:/loginform");
	}
}