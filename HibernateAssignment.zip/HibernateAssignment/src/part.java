import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class part
{
	public static void main(String args[])throws Exception
	{
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		
		
		String empno, name, phoneno, address;
		Scanner s= new Scanner(System.in);
		System.out.println("Enter empno: ");
		empno=s.next();
		System.out.println("Enter name: ");
		name=s.next();
		System.out.println("Enter phoneno: ");
		phoneno=s.next();
		System.out.println("Enter address: ");
		address=s.next();
		
		pojo.setEmpno(empno);
		pojo.setName(name);
		pojo.setPhoneno(phoneno);
		pojo.setAddress(address);
		
		Transaction tx=ss.beginTransaction();
		ss.save(pojo);
		tx.commit();
		
		
		Query q=ss.createQuery("from mypojo");
		List list=q.list();
		System.out.println(list);
		
		List stud=q.list();
		Iterator it=stud.iterator();
		while(it.hasNext())
		{
			pojo=(mypojo)it.next();
			System.out.println(pojo.getEmpno());
			System.out.println(pojo.getName());
			System.out.println(pojo.getPhoneno());
			System.out.println(pojo.getAddress());
		}
		
		
		Transaction tx1=ss.beginTransaction();
		Query q2=ss.createQuery("update mypojo set name=:n where empno=:i"); 
		//we use pojo class name not the table name
		
		q2.setParameter("n","Nitish");
		q2.setParameter("i","101");
		  
		int status=q2.executeUpdate();  
		System.out.println(status); 
		tx1.commit();
		
		Transaction tx2=ss.beginTransaction();
		Query q3=ss.createQuery("delete from mypojo where empno='101' ");  
		//specifying class name (mypojo) not tablename  
		int status1=q3.executeUpdate();
		System.out.println(status1);  
		tx2.commit();  
		
		Query q4=ss.createQuery("select count(empno) from mypojo");  
		System.out.println(q4);
		
	}
}



